/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment3;

import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.Mongo;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import com.mongodb.client.MongoCollection; 
import com.mongodb.client.MongoDatabase; 
import org.bson.Document;  
import com.mongodb.MongoClient; 
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author sandhyamurali
 */
public class Assignment3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        
        
        Assignment3 a3=new Assignment3();

        a3.read_api_file();
        a3.read_mashup_file();
      
        
        
        
    }
    
    public void read_api_file()
    {
        /*
        Reads the api file and loads into the database
        
        */
        MongoClient mongo = new MongoClient( "localhost" , 27017); //connect to mongo
        MongoDatabase db=mongo.getDatabase("mydb"); //access database
        //db.createCollection("api"); //create collection(table name) if not present
        MongoCollection<Document> collection = db.getCollection("api"); //access collection
 
        try 
        {

            File f = new File("/Users/sandhyamurali/Desktop/api.txt");

            BufferedReader b = new BufferedReader(new FileReader(f));

            String readLine = "";
          
            String[] api_col={"id","title","summary","rating","name","label","author","description",
                "type","downloads","useCount","sampleUrl","downloadedUrl","dateModified","remoteFeed","numComments",
            "commentsUrl","Tags","category","protocols","serviceEndpoint","version","wsdl",
            "data formats","apigroups","example","clientInstall","authentication","ssl","readonly","VendorApiKits","CommunityAPIKits",
            "blog","forum","support","accountReq","commercial","provider","managedBy","nonCommercial","dataLicensing",
            "fees","limits","terms","company","updated"};
            
            System.out.println("Reading file using Buffered Reader");
            int count=1;
            while ((readLine = b.readLine()) != null) 
            {
                System.out.println(readLine);
              String[] output = readLine.split("\\$\\#\\$");
              Document d=new Document("count",count);
              
               for(int i=0;i<output.length;i++)
               {
                   output[i]=output[i].trim();
                   if(output[i].length()==0)
                       output[i]="null";
                   else if(output[i].contains("###"))
                   {
                       String replace=output[i].replace("###", ";");
                       output[i]=replace;
                   }
                   
                   
                   d.append(api_col[i], output[i]);
                   
               }
               
               collection.insertOne(d);  //insert into table
                count+=1;
            }
            

        } catch (IOException e) 
        {
            e.printStackTrace();
        }
    }
    
    
    
    public void read_mashup_file()
    {
        /*
        Reads the mashup.txt file and loads into database
        */
        
        MongoClient mongo = new MongoClient( "localhost" , 27017); //connect to db
        MongoDatabase db=mongo.getDatabase("mydb"); //get database
        //db.createCollection("mashup"); //create collection if not present
        MongoCollection<Document> collection = db.getCollection("mashup"); //get collection
        
       
        try 
        {

            File f = new File("/Users/sandhyamurali/Desktop/mashup.txt");

            BufferedReader b = new BufferedReader(new FileReader(f));

            String readLine = "";
          
            String[] mashup_col={"id","title","summary","rating","name","label","author","description",
                "type","downloads","useCount","sampleUrl","dateModified","numComments",
            "commentsUrl","tags","APIs","updated"};
            
            System.out.println("Reading file using Buffered Reader");
            int count=1;
            while ((readLine = b.readLine()) != null) 
            {
                System.out.println(readLine);
              String[] output = readLine.split("\\$\\#\\$");
              Document d=new Document("count",count);
              
               for(int i=0;i<output.length;i++)
               {
                   output[i]=output[i].trim();
                   if(output[i].length()==0)
                       output[i]="null";
                   else if(output[i].contains("###"))
                   {
                       String replace=output[i].replace("###", ";");
                       output[i]=replace;
                       
                       if(output[i].contains("$$$"))
                       {
                           String replace_$=output[i].replace("$$$", "-");
                           output[i]=replace_$;
                           
                       }
                   }
                   
                   else if(output[i].contains("$$$"))
                       {
                           String replace_$=output[i].replace("$$$", "-");
                           output[i]=replace_$;
                           
                       }
                   
                  
                   d.append(mashup_col[i], output[i]);
                   
               }
              
               collection.insertOne(d); //insert into document
               
                count+=1;
            }
            

        } catch (IOException e) 
        {
            e.printStackTrace();
        }
    }
    
    
       
}

